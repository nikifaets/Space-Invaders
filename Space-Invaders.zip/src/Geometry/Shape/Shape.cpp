#include "Shape.h"

Shape::Shape(){}

Shape::Shape(Vector2D pivot){

    this->pivot = pivot;
}

